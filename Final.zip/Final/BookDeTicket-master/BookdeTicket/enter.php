<!DOCTYPE html>
<html lang="en-US">
<head>
	<title>VIT Cinema</title>
	<link rel=icon href="images/favicon.png">
	<meta name='viewport' content="width=device-width, height=device-height, initial-scale=1">
	<meta charset="utf-8">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="style.css">
	<style type="text/css">
		input{
			height: 30px;
			width: initial;
		}
		td{
			width: 200px;
		}
		table{
			margin-left: 50px;
		}
		
		.button {
    background-color: #4CAF50;
    border: 1px;
    color: white;
    padding: 15px 34px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
	align:center;
	border-radius:5px;
	
}
		.but
		{
		 background-color: #4CAF50;
    border: 1px;
    color: white;
		}

	
	.wrapper
	{
	height:1000px;
	}
	
	.container
	{
	float:left;
	width:700px;
	height:120%;
	}
	
	
	.nav-tabs
	{
	list-style-type:none;
	}
	
	#logout
	{
	background-color: #4CAF50;
    border: 1px;
    color: white;
    padding: 15px 34px;
    text-align: center;
    text-decoration: none;
    font-size: 16px;
    cursor: pointer;
	align:right;
	border-radius:5px;
	}
	
	#logout_link
	{
	color:white;
	}
	
	.navbar
	{
	align:right;	
	}
	
		
		
		
	</style>
	
</head>
<body>
<div class="container">
		<div class="navbar">
			<h3>VIT <strong>Cinema</strong></h3>
			<ul class="nav nav-tabs">
			  <li role="presentation" class="active"><a href="schedule.php">Home</a></li>
			  <li role="presentation" class="active"><a href="schedule.php">Manage Movies</a></li>
			  <li role="presentation" class="active"><a href="view.html">View Movies</a></li>
			  <li role="presentation" class="active"><a href="login.php">Logout</a></li>
			</ul>
		</div>
		<center><h1>Welcome Admin</h1></center>
			<?php
$con=mysql_connect("localhost","root","") or die("ddd");
$db=mysql_select_db("bookdeticket",$con);
/*if($con)
echo "connected";*/
$sid=$_POST["sid"];
$mname=$_POST["mn"];
$mshow=$_POST["ms"];
$time=$_POST["st"];
$screen=$_POST["scrt"];
$date=$_POST["dt"];
$pla=$_POST["pt"];
$gold=$_POST["gd"];
$silver=$_POST["sl"];
$mnm=strtolower($mname);
if(!preg_match("/^[0-9]{1}$/",$mshow))
	{
		echo '<script language="javascript">';
echo 'alert("movie show should be number");';
echo 'window.location.href="new.html";';
echo '</script>';
	}
	if(!preg_match("/^[0-9]{1,3}$/",$pla))
	{
		echo '<script language="javascript">';
echo 'alert("movie price should be number");';
echo 'window.location.href="new.html";';
echo '</script>';
	}
	$q1="select * from theatre where movie='$mnm' and show_timings='$time'";
	$r1=mysql_query($q1,$con);
	$num=mysql_num_rows($r1);
	if($num>0)
	{
		echo '<script language="javascript">';
echo 'alert("already scheduled");';
echo 'window.location.href="schedule.php";';
echo '</script>';
	}
$query="insert into theatre values('$sid','$mnm','$mshow','$time','$screen','$date','$pla','$gold','$silver')";
$result=mysql_query($query,$con);
if($result)
	header("location:schedule.php");
else
	echo "error".mysql_error();
?>  
			  	
			  
			
		</div>
		
			<br><br>
		</div>
		<div id="foot">
			<img src="images/clabs-grey.png" style="height: 25px;">
			<h4 style="margin-left: 10px;">VIT <strong>Cinema 2k17</strong></h4>
			<div id="footer">
				<img src="images/youtube.png">
				<h6>YouTube</h6>
				<img src="images/twitter.png">
				<h6>Twitter</h6>
				<img src="images/facebook.png">
				<h6>Facebook</h6>
			</div>
		</div>
	</div>
	
	
	<div style="text-align:center-right" class="wrapper"><img id='myimage' src='2.jpg'/></img></div>
	
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
	<script type="text/javascript" src=script.js></script>
</body>


</html>