 
<?php 
		session_start();
		$conn = mysqli_connect('localhost', 'root', '','bookdeticket');
		$sql="SELECT name FROM movie";
		$result=mysqli_query($conn,$sql);		
		$row=mysqli_fetch_row($result);
		echo $row;
		extract($_POST);
		$mysqli = new mysqli('localhost', 'root','','bookdeticket');
		$mfare=$seats*150;
		$mseats=$seats;
		$_SESSION['tdates']=$tdate;
		$_SESSION['tname']=$row;
		$_SESSION['ttime']=$time;
		$emails=$_SESSION["mailid"];
		$theatres='VIT Cinema';
		$TotalPrice=(($mfare/100)*18+$mfare);
		if($mysqli->connect_errno > 0){
    		die('Unable to connect to database');
		}
			$mysqli->query("select * FROM ticket");
			$query = "INSERT INTO ticket(mname,tdate,theatre,time,seatno,mfare,TotalPrice,email) VALUES ('$row[0]','$tdate','$theatres','$time','$mseats','$mfare','$TotalPrice','$emails')";
			$insert_row = $mysqli->query($query);
			if($insert_row){
			  header("location:seat.php");
			}
			else{
				die('Error : ('. $mysqli->errno .') '. $mysqli->error);
			}
				
	?>
