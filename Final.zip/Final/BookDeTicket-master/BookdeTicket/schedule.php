<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en-US">
<head>
	<title>VIT Cinema</title>
	<link rel=icon href="images/favicon.png">
	<meta name='viewport' content="width=device-width, height=device-height, initial-scale=1">
	<meta charset="utf-8">
	
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
		<!-- Website CSS style -->
		<link rel="stylesheet" type="text/css" href="assets/css/main.css">

		<!-- Website Font style -->
	    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.1/css/font-awesome.min.css">
		
		<!-- Google Fonts -->
		<link href='https://fonts.googleapis.com/css?family=Passion+One' rel='stylesheet' type='text/css'>
		<link href='https://fonts.googleapis.com/css?family=Oxygen' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" type="text/css" href="style.css">
	<style type="text/css">
		input{
			height: 30px;
			width: initial;
		}
		td{
			width: 200px;
		}
		table{
			margin-left: 50px;
		}
		
		.button {
    background-color: #4CAF50;
    border: 1px;
    color: white;
    padding: 15px 34px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
	align:center;
	border-radius:5px;
}
	#login {
    padding-top: 50px
}
#login .form-wrap {
    width: 30%;
    margin: 0 auto;
}
#login h1 {
    color: #1fa67b;
    font-size: 18px;
    text-align: center;
    font-weight: bold;
    padding-bottom: 20px;
}
#login .form-group {
    margin-bottom: 5px;
}
#login .checkbox {
    margin-bottom: 20px;
    position: relative;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    -o-user-select: none;
    user-select: none;
}
#login .checkbox.show:before {
    content: '\e013';
    color: #1fa67b;
    font-size: 17px;
    margin: 1px 0 0 3px;
    position: absolute;
    pointer-events: none;
    font-family: 'Glyphicons Halflings';
}
#login .checkbox .character-checkbox {
    width: 25px;
    height: 25px;
    cursor: pointer;
    border-radius: 3px;
    border: 1px solid #ccc;
    vertical-align: middle;
    display: inline-block;
}
#login .checkbox .label {
    color: #6d6d6d;
    font-size: 13px;
    font-weight: normal;
}
#login .btn.btn-custom {
    font-size: 14px;
	margin-bottom: 20px;
}
#login .forget {
    font-size: 13px;
	text-align: center;
	display: block;
}

/*    --------------------------------------------------
	:: Inputs & Buttons
	-------------------------------------------------- */
.form-control {
    color: #212121;
}
.btn-custom {
    color: #fff;
	background-color: #1fa67b;
}
.btn-custom:hover,
.btn-custom:focus {
    color: #fff;
}	

.main{
 	margin-top: 70px;
}

h1.title { 
	font-size: 50px;
	font-family: 'Passion One', cursive; 
	font-weight: 400; 
}

hr{
	width: 10%;
	color: #fff;
}

.form-group{
	margin-bottom: 10px;
}

label{
	margin-bottom: 10px;
}

input,
input::-webkit-input-placeholder {
    font-size: 11px;
    padding-top: 1px;
}

.main-login{
 	background-color: #fff;
    /* shadows and rounded borders */
    -moz-border-radius: 2px;
    -webkit-border-radius: 2px;
    border-radius: 2px;
    -moz-box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
    -webkit-box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
    box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);

}

.main-center{
 	margin-top: 30px;
 	margin: 0 auto;
 	max-width: 330px;
    padding: 40px 40px;

}

.login-button{
	margin-top: 5px;
}

.login-register{
	font-size: 11px;
	text-align: center;
}
	</style>
	<script src="slider.js"></script>
</head>
<body >

	<div class="container">
		<div class="navbar">
			<h3>VIT <strong>Cinema</strong></h3>
			<ul class="nav nav-tabs">
			  <li role="presentation" class="active"><a href="schedule.php">Home</a></li>
			  <li role="presentation" class="active"><a href="schedule.php">Manage Movies</a></li>
			  <li role="presentation" class="active"><a href="view.html">View Movies</a></li>
			  <li role="presentation" class="active"><a href="login.php">Logout</a></li>
			</ul>
		</div>
		<center><h1>Welcome Admin</h1></center>
		<section id="login">
		<div class="container">
    	<div class="row">
    	    <div class="col-xs-12">
        	<form action="enter.php" method="POST">
				<table>
				<tr><h1>Enter Schedule</h1></tr>
					<tr>
						<td style="font-size:150%">Screen id:</td>
						<!--<td><input type="text" name="sid" required></td>-->
						<!--<td style="font-size:150%">Screen Id:</td>
						<td><input type="radio" name="sid" value="1">1<br></td>
						<td><input type="radio" name="sid" value="2">2<br></td>
						<td><input type="radio" name="sid" value="3">3<br></td>-->
						<td><select name="sid">
						<option name="sid" value="1">1</option>
						<option name="sid" value="2">2</option>
						</select></td>
					</tr>
					<tr><td><br></td></tr>
					<!--<tr><td><input type="radio" name="scrt" value="1">1<br></td></tr>
					<tr><td><br></td></tr>
					<tr><td><input type="radio" name="scrt" value="2">2<br></td></tr>
					<tr><td><br></td></tr>
					<tr><td><input type="radio" name="scrt" value="3">3<br></td></tr>
					<tr><td><br></td></tr>
					<tr><td><br></td></tr>-->
					<tr>
						<td style="font-size:150%">Movie Name:</td>
						<td><input type="text" name="mn" required></td>
					</tr>
					<tr><td><br></td></tr>
					<tr>
						<td style="font-size:150%">Movie Shows:</td>
						<td><input type="text" name="ms" required></td>
					</tr>
					<tr><td><br></td></tr>
					<tr>
						<td style="font-size:150%">Show timings:</td>
						<!--<td><input type="" name="st" required></td>-->
						<td><select name="st">
						<option name="st" value="12:30">12:30 PM</option>
						<option name="st" value="4:00">4:00 PM</option>
						<option name="st" value="8:00">8:00 PM</option>
						</select></td>
					</tr>
					<tr><td><br></td></tr>
					<tr>
						<td style="font-size:150%">Movie Type:</td>
						<td><input type="radio" name="scrt" value="2D" checked>2D
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="scrt" value="3D">3D</td><td></td>
					</tr>
					<tr><td><br></td></tr>
					<tr>
						<td style="font-size:150%">Date:</td>
						<td><input type="date" name="dt" required></td>
					</tr>
					<tr><td><br></td></tr>
					<tr><td style="font-size:150%"><b>Price:</b></td></tr>
					<tr>
						<td style="font-size:130%">Platinum-</td>
						<td><input type="text" name="pt" required></td>
					</tr>
					<tr><td><br></td></tr>
					<tr>
						<td style="font-size:130%">Gold-</td>
						<td><input type="text" name="gd" required></td>
					</tr>
					<tr><td><br></td></tr>
					<tr>
						<td style="font-size:130%">Silver-</td>
						<td><input type="text" name="sl"required></td>
					</tr>
					<tr><td><br></td></tr><tr>
						<center><td><input type="submit" id="btn-login" class="btn btn-custom btn-lg btn-block" value="Enter"></td></td></center>
					</tr>
				</table>
			</form>
			<br><br>
		</div>
		</div></div></div></section>
		<div id="foot">
			<img src="images/clabs-grey.png" style="height: 25px;">
			<h4 style="margin-left: 10px;">VIT <strong>Cinema 2k17</strong></h4>
			<div id="footer">
				<img src="images/youtube.png">
				<h6>YouTube</h6>
				<img src="images/twitter.png">
				<h6>Twitter</h6>
				<img src="images/facebook.png">
				<h6>Facebook</h6>
			</div>
		</div>
	</div>
	
	

	
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
	<script type="text/javascript" src=script.js></script>
</body>

</html>