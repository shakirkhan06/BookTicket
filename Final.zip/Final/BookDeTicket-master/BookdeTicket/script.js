slide=['slide1.png','slide2.png','slide3.png','slide4.png','slide5.png','slide6.png'];
pos=0;
$(document).ready(function(){
	setInterval(function() {
		pos=(pos+1)%6;
		slides=$('#slide-wrap div');
		$(slides).animate({'opacity':0},500, function(){
			for (var i = 0; i < slides.length; i++)
			$(slides[i]).css('background-image','url("images/'+slide[(pos+i)%6]+'")');
			$(slides).css('opacity',1);
		})		
	},3500);
	$('form #open').click(function(){
		if($('#user').trim().val().match(/\W/))
			$('.info').text('Invalid username');
	});
});